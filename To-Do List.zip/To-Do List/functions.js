function removes(e) {
	var id = e.parentNode.id;
	console.log(id);
	window.location.href = "index.php?remoo=" + id; 
}

function edit(e) {
	var editId = e.parentNode.id;
	document.getElementById('text'+editId).removeAttribute('readonly');
	document.getElementById('text'+editId).style.backgroundColor='#F2F29D';
	document.getElementById('pencil'+editId).style.display='none';
	document.getElementById('floppy'+editId).style.display='block';
}

function save(e) {
	console.log('print');
	var editId = e.parentNode.id;
	document.getElementById('text'+editId).setAttribute('readonly','true');
	document.getElementById('text'+editId).style.backgroundColor='#FAF9DC';
	document.getElementById('pencil'+editId).style.display='block';
	document.getElementById('floppy'+editId).style.display='none';
	window.location.href = "index.php?edit=" + editId + "&value=" + document.getElementById('text'+editId).value;
}

