<?php
	
	$servername = "localhost";
	$username = "root";
	$password = "root";
	$dbname = "collpoll";

	// Create connection
	$conn = new mysqli($servername, $username, $password, $dbname);
	// Check connection
	if ($conn->connect_error) {
		echo "connection error";
	    die("Connection failed: " . $conn->connect_error);
	}

	if(isset($_POST['note'])) {
		$list = $_POST['note'];	
		$query = "INSERT INTO SavedNotes (notes)
    			VALUES ('".$list."')";
    	mysqli_query($conn, $query);
	} else {
			$list = "list is empty";
	}
	
	if(isset($_GET['remoo'])) {
		$delete = "DELETE FROM SavedNotes WHERE id=".$_GET['remoo']."";

		if (mysqli_query($conn, $delete)) {
		   // echo "Record deleted successfully";
		} else {
		    echo "Error deleting record: " . mysqli_error($conn);
		}
	}


	if(isset($_GET['edit']) && isset($_GET['value'])) {
		$edit = "UPDATE SavedNotes SET notes='".$_GET['value']."' WHERE id=".$_GET['edit']."";

		if (mysqli_query($conn, $edit)) {
		  //  echo "Record updated successfully";
		} else {
		    echo "Error updating record: " . mysqli_error($conn);
		}
	}
?>


<!DOCTYPE HTML>
<html>
	<head>
		<title> Todo List </title>
	    <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
        <link rel="stylesheet" type="text/css" href="style.css">
        <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.4/css/bootstrap.min.css">
	</head>
	<body>
	<div class="container-fluid">
		<div class="row" >
			<div class="col-md-4 ">
				<form action="index.php" method="post">
					<div class="container"  style="position:fixed; margin-left:4%; margin-top:10%">
						<h1 style="margin-left:5%">ToDo List</h1>
						<textarea class="initextStyle row" name="note" placeholder="Type Here!"></textarea>
						<button class="btn btn-primary row" style="margin-top:5%; margin-left:-15%" type="submit" > Create</button>
					</div>	
				</form>
			</div>
			<div class="col-md-8" style="margin-top:2%">
				<div id="savedNotes">
					<?php 					
						$select = "SELECT id,notes FROM SavedNotes ORDER BY ID DESC";
						$result = mysqli_query($conn, $select);
						$count = mysqli_num_rows($result);
						$incre = 0;
						if (mysqli_num_rows($result) > 0) {
						    // output data of each row
						    echo "<div class='row'>";
						    while($row = mysqli_fetch_assoc($result)) {
						       // echo "id: " . $row["notes"]."<br>";
					    		echo 	"<div class='col-md-4 divStyle' id=".$row["id"].">
						    				<label>".date(" jS \of F Y")." </label>
						    				<textarea class='textStyle' readonly id='text".$row["id"]."'>".$row["notes"]." </textarea>
						    				<i class='glyphicon glyphicon-remove removeStyle' onclick='removes(this)'> </i>
						    				<i class='glyphicon glyphicon-pencil pencilStyle' onclick='edit(this)' id='pencil".$row["id"]."'> </i>
						    				<i class='glyphicon glyphicon-floppy-disk floppyStyle' style='display:none' onclick='save(this)' id='floppy".$row["id"]."'> </i>
					    				</div>";
						    	$incre++;
						    }
						    echo "</div>";
						} else {
						    echo "0 results";
						}

					?>
				</div>
			</div>
		</div>
	</div>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js"></script>
    <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
    <script src="functions.js"></script>
	</body>
</html>
	